<?php

$final_img = imagecreatefrompng('simple.png');
$images = array('organ1.png', 'organ3.png', 'organ4.png');
foreach ($images as $image) {
    $image_layer = imagecreatefrompng($image);
    $width = imagesx ( $image_layer );
    $height = imagesy ( $image_layer );
    imagecopy($final_img, $image_layer, 0, 0, 0, 0, $width, $height);
}
imagesavealpha($final_img, true);
imagealphablending($final_img, true);
header('Content-Type: image/png');
imagepng($final_img, 'bg.png');
imagedestroy($final_img);

?>
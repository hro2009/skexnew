<?php
header ('Content-Type: image/png');
$x = 200;
$y = 200;

$im = imagecreatetruecolor($x, $y);
imagepng($im);
imagedestroy($im);
?>